#include <stdio.h>
#include "stack.h"

void CreateEmpty(Stack *S)
{
  Top(*S) = Nil;
}

boolean IsEmpty(Stack S)
{
  return Top(S) == Nil;
}

boolean IsFull(Stack S)
{
  return Top(S) == MaxEl - 1;
}

// Pada file stack.c, perbarui Push dan Pop
void Push(Stack * S, infotype X) {
    if (!IsFull(*S)) {
        (*S).T[++Top(*S)] = X;
    }
}

void Pop(Stack * S, infotype *X) {
    if (!IsEmpty(*S)) {
        *X = (*S).T[Top(*S)--];
    }
}




