#include <stdio.h>
#include "stack.h" // Include header for stack ADT

int main()
{
  Draf DrafUser;
  Stack drafStack[20]; // Buat 20 stack untuk 20 pengguna
  // int userID = 0;                  // ID pengguna saat ini
  // CreateEmpty(&drafStack[userID]); // Inisialisasi stack untuk pengguna saat ini
  CreateEmpty(&drafStack[0]);
  CreateEmpty(&drafStack[1]);
  CreateEmpty(&drafStack[2]);
  CreateEmpty(&drafStack[3]);
  CreateEmpty(&drafStack[4]);
  CreateEmpty(&drafStack[5]);
  CreateEmpty(&drafStack[6]);
  CreateEmpty(&drafStack[7]);
  CreateEmpty(&drafStack[8]);
  CreateEmpty(&drafStack[9]);
  CreateEmpty(&drafStack[10]);
  CreateEmpty(&drafStack[11]);
  CreateEmpty(&drafStack[12]);
  CreateEmpty(&drafStack[13]);
  CreateEmpty(&drafStack[14]);
  CreateEmpty(&drafStack[15]);
  CreateEmpty(&drafStack[16]);
  CreateEmpty(&drafStack[17]);
  CreateEmpty(&drafStack[18]);
  CreateEmpty(&drafStack[19]);

  printf("Selamat datang! Masukkan perintah atau ketikkan 'SELESAI' untuk keluar.\n");

  while (1)
  {
    int userID;
    printf("Masukkan ID pengguna:\n");
    scanf("%d", &userID);
    // START(); //buat mesin karakter

    printf("BUAT_DRAF atau LIHAT_DRAF\n");
    STARTWORD(); // buat mesin kata

    if (WordEqual(currentWord, stringToWord("SELESAI", 7)))
    {
      // Pengguna ingin keluar
      printf("Terima kasih! Sampai jumpa lagi!\n");
      break;
    }

    if (WordEqual(currentWord, stringToWord("BUAT_DRAF", 9)))
    {
      // Pengguna ingin membuat draf baru
      // Push(&drafStack[userID], currentWord); // Push kata ke dalam stack pengguna
      printf("Masukkan draf:\n");

      // Akuisisi dan simpan draf dalam stack
      STARTWORD();
      while (!EndWord)
      {
        CopyWordTo(&DrafUser.isi, currentWord);
        ADVWORD();
      }
      STARTWORD();
      while (!EndWord)
      {
        CopyWordTo(&DrafUser.tanggal, currentWord);
        Push(&drafStack[userID], DrafUser);
        ADVWORD();
      }

      printf("Apakah anda ingin menghapus, menyimpan, atau menerbitkan draf ini?\n");

      while (1)
      {
        STARTWORD();
        if (WordEqual(currentWord, stringToWord("HAPUS", 5)))
        {
          // Pengguna ingin menghapus draf
          if (!IsEmpty(drafStack[userID]))
          {
            Pop(&drafStack[userID], &DrafUser);
            printf("Draf telah berhasil dihapus!\n");
          }
          else
          {
            printf("Tidak ada draf yang bisa dihapus.\n");
          }
          break;
        }
        else if (WordEqual(currentWord, stringToWord("SIMPAN", 6)))
        {
          // Pengguna ingin menyimpan draf
          printf("Draf telah berhasil disimpan!\n");
          break;
        }
        else if (WordEqual(currentWord, stringToWord("TERBIT", 6)))
        {
          // Pengguna ingin menerbitkan draf
          printf("Selamat! Draf kicauan telah diterbitkan!\n");
          // Tambahkan logikanya untuk menerbitkan draf
          break;
        }
        else if (WordEqual(currentWord, stringToWord("KEMBALI", 7)))
        {
          // Pengguna ingin kembali
          printf("Kembali ke draf sebelumnya.\n");
          break;
        }
        else
        {
          printf("Perintah tidak valid. Silakan masukkan 'HAPUS', 'SIMPAN', 'TERBIT', atau 'KEMBALI'.\n");
        }
      }
    }
    else if (WordEqual(currentWord, stringToWord("LIHAT_DRAF", 10)))
    {
      // Pengguna ingin melihat draf terakhir
      if (!IsEmpty(drafStack[userID]))
      {
        printf("Ini draf terakhir anda:\n");
        printWord(InfoTop(drafStack[userID]).isi);
        printf("\n");
        printWord(InfoTop(drafStack[userID]).tanggal);

        printf("\nApakah anda ingin mengubah, menghapus, atau menerbitkan draf ini? (KEMBALI jika ingin kembali)\n");

        while (1)
        {
          STARTWORD();
          if (WordEqual(currentWord, stringToWord("HAPUS", 5)))
          {
            // Pengguna ingin menghapus draf
            if (!IsEmpty(drafStack[userID]))
            {
              Pop(&drafStack[userID], &DrafUser);
              printf("Draf telah berhasil dihapus!\n");
            }
            else
            {
              printf("Tidak ada draf yang bisa dihapus.\n");
            }
            break;
          }
          else if (WordEqual(currentWord, stringToWord("UBAH", 4)))
          {
            // Pengguna ingin mengedit draf
            printf("Masukkan draf yang baru:\n");

            // Akuisisi dan simpan draf baru dalam stack

            STARTWORD();
            while (!EndWord)
            {
              CopyWordTo(&DrafUser.isi, currentWord);
              ADVWORD();
            }
            
            STARTWORD();
            while (!EndWord)
            {
              CopyWordTo(&DrafUser.tanggal, currentWord);
              Push(&drafStack[userID], DrafUser);
              ADVWORD();
            }

            printf("Apakah anda ingin menghapus, menyimpan, atau menerbitkan draf ini?\n");

            while (1)
            {
              STARTWORD();
              if (WordEqual(currentWord, stringToWord("HAPUS", 5)))
              {
                // Pengguna ingin menghapus draf
                if (!IsEmpty(drafStack[userID]))
                {
                  Pop(&drafStack[userID], &DrafUser);
                  printf("Draf telah berhasil dihapus!\n");
                }
                else
                {
                  printf("Tidak ada draf yang bisa dihapus.\n");
                }
                break;
              }
              else if (WordEqual(currentWord, stringToWord("SIMPAN", 6)))
              {
                // Pengguna ingin menyimpan draf
                printf("Draf telah berhasil disimpan!\n");
                break;
              }
              else if (WordEqual(currentWord, stringToWord("TERBIT", 6)))
              {
                // Pengguna ingin menerbitkan draf
                printf("Selamat! Draf kicauan telah diterbitkan!\n");
                // Tambahkan logikanya untuk menerbitkan draf
                break;
              }
              else if (WordEqual(currentWord, stringToWord("KEMBALI", 7)))
              {
                // Pengguna ingin kembali
                printf("Kembali ke draf sebelumnya.\n");
                break;
              }
              else
              {
                printf("Perintah tidak valid. Silakan masukkan 'HAPUS', 'SIMPAN', 'TERBIT', atau 'KEMBALI'.\n");
              }
            }

            break;
          }
          else if (WordEqual(currentWord, stringToWord("TERBIT", 6)))
          {
            // Pengguna ingin menerbitkan draf
            printf("Selamat! Draf kicauan telah diterbitkan!\n");
            // Tambahkan logikanya untuk menerbitkan draf
            break;
          }
          else if (WordEqual(currentWord, stringToWord("KEMBALI", 7)))
          {
            // Pengguna ingin kembali
            printf("Kembali ke draf sebelumnya.\n");
            break;
          }
          else
          {
            printf("Perintah tidak valid. Silakan masukkan 'HAPUS', 'UBAH', 'TERBIT', atau 'KEMBALI'.\n");
          }
        }
      }
      else
      {
        printf("Yah, anda belum memiliki draf apapun! Buat dulu ya :D\n");
      }
    }
    else
    {
      printf("Perintah tidak valid. Silakan masukkan 'BUAT_DRAF' atau 'LIHAT_DRAF'.\n");
    }
  }

  return 0;
}
